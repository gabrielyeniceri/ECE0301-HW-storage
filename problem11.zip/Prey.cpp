#include "Prey.hpp"

const int Prey::MOVES = 2;
const int Prey::MOVE_ENERGY = 5;

// TODO