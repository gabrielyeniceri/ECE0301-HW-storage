#ifndef _FLORA_HPP
#define _FLORA_HPP

#include "Agent.hpp"

class Flora : public Agent {
    public:
        static const int PHOTO_ENERGY;
        static const int GROW_ENERGY;
        static const int MOVES;
        
        // TODO
       
};

#endif