#include "Flora.hpp"

const int Flora::PHOTO_ENERGY = 5;
const int Flora::GROW_ENERGY = 20;
const int Flora::MOVES = 4;

// TODO
