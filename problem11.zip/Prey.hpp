#ifndef _PREY_HPP
#define _PREY_HPP

#include "Agent.hpp"

class Prey : public Agent {
    public:
        static const int MOVES;
        static const int MOVE_ENERGY;

        // TODO
        
};

#endif