#ifndef _DATABASE_HPP
#define _DATABASE_HPP

#include <string>

struct Entry {
    int id;
    std::string name;
    double mass;
};

// Database class declaration here



#endif