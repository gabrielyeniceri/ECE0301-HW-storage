#include "VoltageSource.hpp"

double VoltageSource::get_voltage() const
{
    // TODO
    return 0.0;
}
