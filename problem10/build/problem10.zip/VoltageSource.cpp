#include "VoltageSource.hpp"

double VoltageSource::get_voltage() const
{
    return get_value();
}
