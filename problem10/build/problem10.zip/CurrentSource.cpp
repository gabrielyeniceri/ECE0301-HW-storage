#include "CurrentSource.hpp"

double CurrentSource::get_current() const
{
   return get_value();
}
